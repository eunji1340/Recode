package com.ssafy.recode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
