package com.ssafy.recode.domain.tag.entity;

public class Tag {
}
