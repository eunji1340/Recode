//package com.ssafy.recode.domain.tag.controller;
//
//import com.ssafy.recode.domain.feed.service.FeedService;
//import lombok.RequiredArgsConstructor;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//@RequestMapping("/tag")
//@RequiredArgsConstructor
//public class TagController {
//
//    private final FeedService feedService;
//
//}
