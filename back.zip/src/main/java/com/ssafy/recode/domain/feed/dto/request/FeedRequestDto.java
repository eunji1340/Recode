package com.ssafy.recode.domain.feed.dto.request;

import lombok.Getter;

@Getter
public class FeedRequestDto {
    private String content;
}
