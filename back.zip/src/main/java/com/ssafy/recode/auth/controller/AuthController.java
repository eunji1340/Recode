package com.ssafy.recode.auth.controller;

public class AuthController {
}
